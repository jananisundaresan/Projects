How to run the code:

1. Open the file in jupyter notebook
2. Run the notebook